const { Client } = require("@modelcontextprotocol/sdk/client/index.js");
const {
  StdioClientTransport
} = require("@modelcontextprotocol/sdk/client/stdio.js");

async function main() {
  console.log("Starting MCP client...\n");

  const transport = new StdioClientTransport({
    command: "node",
    args: ["src/mcp/server.js"]
  });

  const client = new Client({
    name: "test-client",
    version: "1.0.0"
  });

  try {
    // Connect to MCP server
    await client.connect(transport);

    console.log("Connected to MCP server!\n");

    // Get available tools
    const tools = await client.listTools();

    console.log("Available tools:");

    tools.tools.forEach((tool) => {
      console.log(`- ${tool.name}`);
    });

    // Test search_products
    console.log("\nTesting search_products...\n");

    const result = await client.callTool({
      name: "search_products",
      arguments: {
        category: "Gaming Laptop",
        maxPrice: 80000
      }
    });

    console.log("Search result:");
    console.log(result.content[0].text);

    await client.close();

    console.log("\nMCP test completed successfully!");

  } catch (error) {
    console.error("\nMCP test failed:");
    console.error(error);
  }
}

main();