require('dotenv').config();
const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const connectDB = require('../config/db');

// Import MCP tools
const searchProductsTool = require('./tools/searchProducts');
const getProductTool = require('./tools/getProduct');
const checkInventoryTool = require('./tools/checkInventory');

// Initialize MCP server
const server = new Server(
  {
    name: 'merchant-commerce-server',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Register all tools
const tools = [
  searchProductsTool,
  getProductTool,
  checkInventoryTool
];

// Tool list handler
server.setRequestHandler({
  method: 'tools/list'
}, async () => {
  return {
    tools: tools.map(t => t.tool)
  };
});

// Tool call handler
server.setRequestHandler({
  method: 'tools/call'
}, async (request) => {
  const toolName = request.params.name;
  const args = request.params.arguments || {};

  // Find the requested tool
  const tool = tools.find(t => t.tool.name === toolName);

  if (!tool) {
    throw new Error(`Unknown tool: ${toolName}`);
  }

  // Execute the tool
  return await tool.execute(args);
});

// Main function to start the MCP server
async function main() {
  try {
    console.log('[MCP] Starting Merchant Commerce MCP Server...');

    // Connect to MongoDB before accepting requests
    await connectDB();
    console.log('[MCP] MongoDB connected successfully');

    // Create stdio transport
    const transport = new StdioServerTransport();
    
    // Connect server to transport
    await server.connect(transport);
    
    console.log('[MCP] Server ready and listening on stdio');
    console.log('[MCP] Available tools:');
    tools.forEach(t => {
      console.log(`  - ${t.tool.name}: ${t.tool.description}`);
    });
  } catch (error) {
    console.error('[MCP] Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('[MCP] Shutting down...');
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('[MCP] Shutting down...');
  process.exit(0);
});

// Start the server
main();
