const productService = require('../../services/productService');

/**
 * MCP Tool: search_products
 * Search the merchant's product catalog using structured filters
 */
const searchProductsTool = {
  name: 'search_products',
  description: 'Search the merchant\'s product catalog. Use this when a customer wants to find products based on category, price, specifications, brand, GPU, refresh rate, or availability. Returns matching products with detailed information.',
  inputSchema: {
    type: 'object',
    properties: {
      category: {
        type: 'string',
        description: 'Product category (e.g., "Gaming Laptop", "Monitor", "Keyboard")'
      },
      brand: {
        type: 'string',
        description: 'Brand name (e.g., "ASUS", "Samsung", "Logitech")'
      },
      minPrice: {
        type: 'number',
        description: 'Minimum price in INR'
      },
      maxPrice: {
        type: 'number',
        description: 'Maximum price in INR'
      },
      ram: {
        type: 'number',
        description: 'RAM in GB (exact match)'
      },
      storage: {
        type: 'number',
        description: 'Storage in GB (exact match)'
      },
      gpu: {
        type: 'string',
        description: 'GPU model (partial match, e.g., "RTX 5070")'
      },
      refreshRate: {
        type: 'number',
        description: 'Minimum refresh rate in Hz'
      },
      inStock: {
        type: 'boolean',
        description: 'Only show products that are currently in stock'
      }
    }
  }
};

async function executeSearchProducts(args) {
  try {
    console.log('[MCP] search_products called with filters:', JSON.stringify(args));

    // Convert inStock boolean to string for service compatibility
    const filters = {
      ...args,
      inStock: args.inStock !== undefined ? String(args.inStock) : undefined
    };

    // Call existing product service
    const products = await productService.searchProducts(filters);

    // Format response for AI agent
    const formattedProducts = products.map(product => ({
      id: product._id.toString(),
      name: product.name,
      brand: product.brand,
      category: product.category,
      price: product.price,
      currency: product.currency,
      stock: product.stock,
      specifications: product.specifications,
      rating: product.rating,
      deliveryDays: product.deliveryDays,
      description: product.description
    }));

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            count: formattedProducts.length,
            products: formattedProducts
          }, null, 2)
        }
      ]
    };
  } catch (error) {
    console.error('[MCP] search_products error:', error);
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            error: 'Failed to search products',
            message: error.message
          })
        }
      ],
      isError: true
    };
  }
}

module.exports = {
  tool: searchProductsTool,
  execute: executeSearchProducts
};
