const productService = require('../../services/productService');
const mongoose = require('mongoose');

/**
 * MCP Tool: check_inventory
 * Check if a product is currently available in stock
 */
const checkInventoryTool = {
  name: 'check_inventory',
  description: 'Check whether a specific product is currently available in stock. Returns availability status and current stock level. This is a read-only operation.',
  inputSchema: {
    type: 'object',
    properties: {
      productId: {
        type: 'string',
        description: 'The unique product ID (MongoDB ObjectId)'
      }
    },
    required: ['productId']
  }
};

async function executeCheckInventory(args) {
  try {
    console.log('[MCP] check_inventory called with ID:', args.productId);

    // Validate product ID format
    if (!mongoose.Types.ObjectId.isValid(args.productId)) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              error: 'Invalid product ID format',
              productId: args.productId
            })
          }
        ],
        isError: true
      };
    }

    // Call existing product service
    const product = await productService.getProductById(args.productId);

    if (!product) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              error: 'Product not found',
              productId: args.productId
            })
          }
        ],
        isError: true
      };
    }

    // Format inventory response
    const inventoryStatus = {
      productId: product._id.toString(),
      name: product.name,
      available: product.stock > 0,
      stock: product.stock,
      isActive: product.isActive
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(inventoryStatus, null, 2)
        }
      ]
    };
  } catch (error) {
    console.error('[MCP] check_inventory error:', error);
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            error: 'Failed to check inventory',
            message: error.message
          })
        }
      ],
      isError: true
    };
  }
}

module.exports = {
  tool: checkInventoryTool,
  execute: executeCheckInventory
};
