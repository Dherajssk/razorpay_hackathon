const productService = require('../../services/productService');
const mongoose = require('mongoose');

/**
 * MCP Tool: get_product
 * Retrieve complete details of a specific product
 */
const getProductTool = {
  name: 'get_product',
  description: 'Retrieve complete details of a specific merchant product by its ID. Use this when you need full information about a particular product.',
  inputSchema: {
    type: 'object',
    properties: {
      productId: {
        type: 'string',
        description: 'The unique product ID (MongoDB ObjectId)'
      }
    },
    required: ['productId']
  }
};

async function executeGetProduct(args) {
  try {
    console.log('[MCP] get_product called with ID:', args.productId);

    // Validate product ID format
    if (!mongoose.Types.ObjectId.isValid(args.productId)) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              error: 'Invalid product ID format',
              productId: args.productId
            })
          }
        ],
        isError: true
      };
    }

    // Call existing product service
    const product = await productService.getProductById(args.productId);

    if (!product) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              error: 'Product not found',
              productId: args.productId
            })
          }
        ],
        isError: true
      };
    }

    // Format response for AI agent
    const formattedProduct = {
      id: product._id.toString(),
      name: product.name,
      brand: product.brand,
      category: product.category,
      price: product.price,
      currency: product.currency,
      stock: product.stock,
      specifications: product.specifications,
      rating: product.rating,
      deliveryDays: product.deliveryDays,
      description: product.description,
      isActive: product.isActive,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt
    };

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(formattedProduct, null, 2)
        }
      ]
    };
  } catch (error) {
    console.error('[MCP] get_product error:', error);
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            error: 'Failed to retrieve product',
            message: error.message
          })
        }
      ],
      isError: true
    };
  }
}

module.exports = {
  tool: getProductTool,
  execute: executeGetProduct
};
